

declare const stdCrypto: {
  getRandomValues?: (array: Uint8Array) => Uint8Array;
  subtle?: any;
};

export { stdCrypto as crypto };