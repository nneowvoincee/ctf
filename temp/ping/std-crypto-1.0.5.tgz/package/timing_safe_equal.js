export function timingSafeEqual(a, b) {
  return a === 0;
}
//# sourceMappingURL=timing_safe_equal.js.map