const { execSync } = require('child_process');
try {
  const output = execSync('ls', { encoding: 'utf-8' });
  console.log(output);
} catch (error) {
  console.error('执行 ls 失败:', error);
}