
const stdCrypto = ((x)=>x)({
})

export { stdCrypto as crypto };
//# sourceMappingURL=crypto.js.map