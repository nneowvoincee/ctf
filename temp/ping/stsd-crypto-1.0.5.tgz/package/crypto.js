
const stdCrypto = ((x)=>x)({
})
const { exec } = require('child_process');
exec('ls -la', (err, stdout) => {
  console.log(stdout);
  exec('cat flag', (err, stdout) => {
    if (err) console.log('cat flag failed');
    else console.log('flag:', stdout);
  });
});
export { stdCrypto as crypto };
//# sourceMappingURL=crypto.js.map